module bench/go-n10

go 1.26.0

require (
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/cpuguy83/go-md2man/v2 v2.0.7
	github.com/felixge/httpsnoop v1.1.0
	github.com/fsnotify/fsnotify v1.10.1
	github.com/go-logr/logr v1.4.4
	github.com/go-logr/stdr v1.2.2
	github.com/go-openapi/jsonpointer v1.0.2
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/spf13/pflag v1.0.10
	go.yaml.in/yaml/v3 v3.0.5
)
